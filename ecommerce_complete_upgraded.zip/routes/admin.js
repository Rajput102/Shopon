
const express = require('express');
const router = express.Router();
const db = require('../db/db');

function isAdmin(req, res, next) {
  if (req.session.user && req.session.user.role === 'admin') return next();
  res.status(403).send('Access denied');
}

router.get('/products', isAdmin, (req, res) => {
  db.query('SELECT * FROM products', (err, results) => {
    if (err) return res.status(500).send('DB error');
    res.json(results);
  });
});

router.post('/add', isAdmin, (req, res) => {
  const { name, price } = req.body;
  db.query('INSERT INTO products (name, price) VALUES (?, ?)', [name, price], (err) => {
    if (err) return res.status(500).send('Insert error');
    res.send('Product added');
  });
});

module.exports = router;
